/*
- Author: Abdullah Arishi
- input: 2 numbers( a base and an exponent).
_ output: 1 number.
- describtion: this code will calculate a base and raise things to integer powers and gives us the result.
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double myPower(double base,int exp)
{
       double retval;
   if(base==0.0&&exp>=0) // first condition
   {

       retval=0.0;
   }
   else if(base==0.0&&exp<0) // second condition
   {
       retval=INFINITY;
   }
   else if(base!=0.0&&exp==0) // third condition
   {
            retval=1.0;
   }
   else if(base!=0 && exp<0) // fourth condition
   {

       base=1.0/base;
       exp=(-1)*exp;
       retval=1.0;
       for(int i=0;i<exp;i++)
       {
           retval=retval*base;
       }
   }
   else //if both  base and exponent are positive
   {
           retval=1.0;
       for(int i=0;i<exp;i++)
       {
           retval=(retval*base);
       }

   }

   return retval;
}
int main()
{
   double base;
   int exp;
   printf("Enter the base\n"); //input from the user for base
   scanf("%lf",&base);
   printf("Enter the exponent\n"); //input from  the user for exponent
   scanf("%d",&exp);

   double result=myPower(base,exp); //calling the function

   printf("%.2f\n",result); // displaying result

}
