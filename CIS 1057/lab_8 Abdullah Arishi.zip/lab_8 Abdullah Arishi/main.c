//* Auther: Abdullah Arishi
//* Date:sept, 25, 2019
//* input: one integer number
// * output: state of lights
// * describtion: this code will print out the state of all n lights

#include <stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
int n,i,j;
printf("Enter n:");
scanf("%d",&n);//read n
int a[n+1];//allocate n+1 size for array
memset(a,0,(n+1)*sizeof(int));//assign 0 to whole array at start
for(i=1;i<=n;i++)//loop n times
{
for(j=1;j<=n;j++)//for each run
{
if(j%i==0)//if it is divisible by that run
{
if(a[j]==0)//change the state to 0 or 1
a[j]=1;
else if(a[j]==1)
a[j]=0;
}
}
for(int k=1;k<=n;k++)//print values after changing for each run
printf("%d ",a[k]);
printf("\n");
}
  
for(i=1;i<=n;i++)
{
if(a[i]==1)
printf("%d -> ON\n",i);
else
printf("%d -> OFF\n",i);
}
return 0;
}

// I realized that the pattern was with the off state it kept increasing by 2 each in each run, it starts at 2 then 4,6,8..... and so on
