/*
 - Author: Abdullah Arishi
- Date: Oct 7th, 2019
- input: answer whther the num is true, low, or high
- Output: a guess from the cpu and my answer of the guesssing number
- Description: this code is about me thinking of a number between 1 to 100 and the computer will suggest a number then i will answer upon the computer's suggeted number whether it's true, low, high.
finlly printing the number of turns.
 
*/





#include <stdio.h>
#include <stdlib.h>



void main()
{

	char cpu;
	int minimum = 1;
	int maximum = 100;
	int guess = maximum/2;
	int numTurn = 1;

	printf("Think of a number from %d to %d, I can guess your num within 7 turns\n",minimum, maximum);


	while(cpu != '='){


		printf("is your num %d ? \n", guess);
		printf("(1) =\n");
                printf("(2) >\n");
                printf("(3) <\n");
		scanf(" %c", &cpu);	// get an answer  whether its true, low or high

		if(cpu  == '<'){
			maximum = guess;
			guess = (minimum + maximum)/2;  // Updating the new low  range
		}
		else if(cpu  =='>'){
			minimum  = guess;
			guess = (maximum + minimum)/2; // Updating the high range
		}
		else if( cpu == '='){
			printf("I gussed your number in %d\n", numTurn); // printing out the number of turns
		}
		else
			printf("Invalid Input\n");
		numTurn++;   // incrementing the number of turns
	}

}



