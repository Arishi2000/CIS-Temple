/*
- Author = Abdullah Arishi
- Date: Oct 21, 2019
- input: no input
- output: 3 integer numbers and first and last charachter of a string
- Description: this code contain three function the first one will double a number, the second one will swap two numbers, and the third one will displey the first and last characters in alphabet
 of a string
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void doubleMe(int *x)
{
*x = *x * 2;
}

void swap(double *a, double *b)
{
double temp; //make a temp variable to store value of b
temp = *a;
*a = *b;
*b = temp;
}

void firstLast(char theString[], char *first, char *last)
{
char min,max;       //two variables to store value of first and last
min = theString[0];
for(int i=0;i<strlen(theString);i++){       //I used strlen  to find the length of the  string
if(theString[i] < min){         //comparing the ASCII values of characters
min = theString[i];
}
}
*first = min;
max = theString[0];
for(int i=0;i<strlen(theString);i++){
if(theString[i] > max){
max = theString[i];
}
}
*last = max;
}

void main(){


int doubleValue=10;             // declaring a varible fot the first function to double it
double n=4,m=6;                 // declaring two varibales for the swapping function
char word[] = "computer",c,d;   // declaring a string for the lat function
doubleMe(&doubleValue);         // calling the first function
printf("Double = %d\n",doubleValue);            // displaying the result of the first function
printf("The values before the swapping is %f and %f\n",n,m);    // displaying the reslut of the second function
swap(&n,&m);                                                    // calling the the seconed function
printf("The values after the swapping is %f and %f\n",n,m);         // displaying the result of the second function
firstLast(word,&c,&d);                                              // calling the third function
printf("The word is computer\n");
printf("First character = %c and Last character = %c\n",c,d);       // displaying the result of the third function
}
