#define MAXNUM 100


typedef struct person
{
  double height;
  double weight;
} Person;

//prototypes follow:
int getData(FILE *input, Person people[], int max);
void getAverages(Person people[], double *aveHeight, double *aveWeight, int numPeople);
void getStandardDevs(Person people[], double aveHeight, double aveWeight, 
                      double *stdHeight, double *stdWeight, int numPeople);

