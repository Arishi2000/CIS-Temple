/*
Author: Abdullah Arishi
Date: Nov 1st, 2019
input:Vaules.dat
output: number of people, the average weight, the average height, the standerd deviation of the weight, and the standerd deviation of the height.
Description:this code will calculate the number of people, the average weight, the average height, the standerd deviation of the weight, and the standerd deviation of the height
from values.dat file and will print out the output.
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "stats.h"


void main(void)
{
  char filename[] = "values.dat";
  FILE *input;
  Person people[MAXNUM];
  int numPeople;
  double aveHeight, aveWeight, stdHeight, stdWeight;

  input = fopen("values.dat", "r");    // read file
  numPeople = getData(input, people, MAXNUM);
  fclose(input);    // close the file
  getAverages(people, &aveHeight, &aveWeight, numPeople);
  getStandardDevs(people, aveHeight, aveWeight, &stdHeight, &stdWeight, numPeople);

  printf("Number of people %d\n", numPeople);
  printf("****  Stats ****\n");
  printf("The average weight is %lf\n", aveWeight);
  printf("The average height is %lf\n", aveHeight);
  printf("The standard deviation of the weights is %lf\n", stdWeight);
  printf("The standard deviation of the heights is %lf\n", stdHeight);

}


  int getData(FILE *input, Person people[],int max){
    // if file not exist print cannot open file
	if(input == NULL){
		printf("Cannot open file\n");
		exit(1);
	}
	int numPeople = 0;
	int i;
	while(!feof(input)){
		i = fscanf(input, "%lf %lf", &people[numPeople].height,&people[numPeople].weight);
		if(i==2){
			numPeople++;
		}
	}
	return numPeople;
      }
	void getAverages(Person people[], double *aveHeight, double *aveWeight, int numPeople){

	 for(int i = 0;i <numPeople;i++){
        // sum the heights and weights
        *aveHeight = *aveHeight + people[i].height;
		*aveWeight = *aveWeight + people[i].weight;
	}
    // devide the sum of height and weights by number of people to get average
    *aveHeight = *aveHeight / numPeople;
	*aveWeight = *aveWeight / numPeople;
      }
	void getStandardDevs(Person people[],double aveHeight,double aveWeight,double *stdHeight,double *stdWeight,int numPeople){

// declare height_sum and weight_sum to add sum produced in each iteration

    double  sum_height = 0.0, sum_weight = 0.0;
	double result;
	 for(int i = 0; i< numPeople; i++){
		 result = people[i].height - aveHeight;      // find difference between height of people[i] and average height, store it into result
         result = result * result;
         // add the result to height_sum
         sum_height += result;

		result = people[i].weight- aveWeight;
		result = result * result;
		sum_weight += result;
	 }
// find the square root of height_sum divided by number of people to get standard deviation of heights
     *stdHeight = sqrt(sum_height / (numPeople - 1));

// find the square root of weight_sum divided by number of people to get standard deviation of weights
	 *stdWeight = sqrt(sum_weight / (numPeople - 1 ));
}
