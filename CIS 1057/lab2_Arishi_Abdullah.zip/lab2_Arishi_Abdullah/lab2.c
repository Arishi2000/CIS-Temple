/*
* Author: Abdullah Arishi
* Date: sept 23,2019
* input: there is no input in the code
* output: values of f(0) through f(20).each one with its own ratio. 
* description: this code  will caluclate f(n) by(fn-1) + f(n-2) from f(0) through f(20) with printing out their ratios by casting the two int to doubles before dividing.o.

*/

#include <stdio.h>
#include <stdlib.h>

void main(void){
	int i;
	int twoback = 1;
	int oneback = 1;
	int curr_fib;
	double ratio;



	for(i=0; i<=20;i++){
		if(i==0){
                        printf("f(0) = 1. ratio is undefined\n");
                }
                else if (i==1){
                        ratio = (double)oneback/twoback;
                        printf("f(1) = 1. ratio is %lf\n", ratio);
                }
		else{
			curr_fib = oneback + twoback;
	  		ratio = (double)curr_fib/oneback;
			twoback = oneback;
                	oneback = curr_fib;
			printf("f(%d) = %d Ratio is %lf\n", i, curr_fib, ratio);
		}
	}
}


