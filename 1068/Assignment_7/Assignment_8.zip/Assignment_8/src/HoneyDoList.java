/*
Author: Dom(Abdullah) Arishi
Date: 2/28/2020
 */


public class HoneyDoList {

    //Instance variables
    private Task[] tasks;
    private int numOfTasks;
    private final int INITIAL_CAPACITY=10;
    //Constructor
    public HoneyDoList() {
        tasks=new Task[INITIAL_CAPACITY];
        numOfTasks=0;
    }
    //To string method
    public String toString() {
        if(numOfTasks==0) {
            return null;
        }
        else {
            String str="";
            for(int i=0;i<numOfTasks;i++) {
                str+=tasks[i]+"\n";
            }
            return str;
        }
    }
    //Find a task index
    public int find(String name) {
        for(int i=0;i<numOfTasks;i++) {
            if(name.equalsIgnoreCase(tasks[i].getName())) {
                return i;
            }
        }
        return -1;
    }
    //Add a new tasks
    public void addTasks(Task t) {
        if(tasks.length==numOfTasks) {
            Task[] tempTasks=new Task[numOfTasks+1];
            tempTasks=tasks;
            tempTasks[numOfTasks]=t;
            tasks=new Task[numOfTasks+1];
            tasks=tempTasks;
            numOfTasks++;
        }
        else {
            tasks[numOfTasks]=t;
            numOfTasks++;
        }
    }
    //Get total time
    public int totalTime()
    {
        int total=0;
        for(int i=0;i<numOfTasks;i++) {
            total+=tasks[i].getEstimateMinToComplete();
        }
        return total;
    }
    //Get shortest time task index
    public int shortestTime() {
        if(numOfTasks==0) {
            return -1;
        }
        else {
            int shortest=0;
            for(int i=0;i<numOfTasks;i++) {
                if(shortest>tasks[i].getEstimateMinToComplete()) {
                    shortest=tasks[i].getEstimateMinToComplete();
                }

            }
            return shortest;
        }
    }
    //Remove completed tasks
    public Task completeTask(int index) {
        if(index<0 && index>numOfTasks) {
            return null;
        }
        else {
            Task t=tasks[index];
            for(int i=index;i<numOfTasks-1;i++) {
                tasks[i]=tasks[i-1];
            }
            return t;
        }
    }
}