import java.time.LocalDateTime;

public class TaskMain {

	public static void main(String[] args) {
		Task task=new Task("post 1068 homework.",1,LocalDateTime.of(2019,3,23,13,0),180);
			System.out.println(""+task);
			System.out.println("Task Overdue :"+task.overdue());
		}
	}

