/*
Author: Dom(Abdullah) Arishi
Date: 2/28/2020
 */

import java.time.LocalDateTime;

//Create a class Task
public class Task {
	// variables
	private String name;
	private int priority;
	private int estMinToComplete;
	private LocalDateTime whenDue;
	//Constructor
	public Task(String n,int p,LocalDateTime due,int est) {
		if(p<0) {
			priority=0;
		}
		else {
			priority=p;
		}
		if(est<0) {
			estMinToComplete=0;
		}
		else {
			estMinToComplete=est;
		}
		name=n;
		whenDue=due;
	}
	//Accessors
	public String getName() {
		return name;
	}
	public int getPriority() {
		return priority;
	}
	public int getEstimateMinToComplete() {
		return estMinToComplete;
	}
	public LocalDateTime getWhenDue() {
		return whenDue;
	}
	//Mutators
	public void setName(String n) {
		name=n;
	}
	public void setPriority(int p) {
		if(p<0) {
			priority=0;
		}
		else {
			priority=p;
		}
	}
	public void setWhenDue(LocalDateTime due) {
		whenDue=due;
	}
	public void setEstimateMinToComplete(int est) {
		if(est<0) {
			estMinToComplete=0;
		}
		else {
			estMinToComplete=est;
		}
	}
	//toString method
	public String toString() {
		String str="";
		str+="I have "+name+"\n";
		str+="This has a priority of "+priority+", should take "+estMinToComplete+" minutes\n";
		String date=whenDue.getMonth().name();
		date+=" "+whenDue.getDayOfMonth();
		date+=", "+whenDue.getYear();
		str+="and it's due is "+date;
		return str+", at "+whenDue.toLocalTime();
	}
	//Increase priority
	public void increasePriority(int amount) {
		if(amount>=0) {
			priority+=amount;
		}
	}
	//Decrease priority
	public void decreasePriority(int amount) {
		if(amount>=priority) {
			priority=0;
		}
		else {
			priority-=amount;
		}
	}
	// overdue method to show the current date whether it has pasted it or not
	public boolean overdue() {
		if(LocalDateTime.now().isAfter(whenDue))
			return true;
		else
			return false;
	}
}
