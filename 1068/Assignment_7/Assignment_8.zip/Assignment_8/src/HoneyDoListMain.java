
import java.time.LocalDateTime;

public class HoneyDoListMain {

       public static void main(String[] args) {
           HoneyDoList honeyDo=new HoneyDoList();
           System.out.println(honeyDo);
           honeyDo.addTasks(new Task("Take Aspirin",1,LocalDateTime.of(2019,3,23,13,0),120));
           System.out.println(honeyDo);
           System.out.println("Index of shortest time="+honeyDo.shortestTime());
       }

   }