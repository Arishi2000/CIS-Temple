#include <stdio.h>

void take_last(char *s, int n){
  int len1=0;

while(s[len1]!='\0'){

len1++;

}

int i=0;

int start=len1-n;

if(n<len1){

while(start<len1){

s[i] = s[start];

i++;

start++;

}

s[i] ='\0';

}
}//end of function
