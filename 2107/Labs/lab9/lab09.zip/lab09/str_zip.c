#include<stdio.h>

char *str_zip(char *s1, char *s2){
int len_s1, len_s2;
for(len_s1 = 0; *(s1 + len_s1) != '\0'; len_s1++);
for(len_s2 = 0; *(s1 + len_s2) != '\0'; len_s2++);
int tot_len = len_s1 + len_s1;
char* result = (char*)malloc(tot_len);
   char* res2 = result;
   while( *s1 != '\0' && *s2 != '\0' ){
       *res2 = *s1;
       res2++;
       *res2 = *s2;
       res2++;    s1++; s2++;
   }
   while( *s1 != '\0' ){
       *res2 = *s1;
       res2++; s1++;
   }
   while( *s2 != '\0' ){
       *res2 = *s2;
       res2++; s2++;
   }
   return result;

} //end of function



