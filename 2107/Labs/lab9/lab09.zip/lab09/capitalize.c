#include<stdio.h>

void capitalize(char *s){
  int i=0;

  for(i=0; s[i]; i++){
    if(s[i]>= 'a' && s[i]<='z')
      s[i] -=32;
  }
}// end of function
