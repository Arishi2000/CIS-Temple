#include<stdio.h>

int diff(char *s1, char *s2){
  int len_s1, len_s2;
  
  for(len_s1 = 0; *(s1 + len_s1) != '\0'; len_s1++);
  for(len_s2 = 0; *(s2 + len_s2) != '\0'; len_s2++);
  
  int diffr=0;
  int i,j;
  if(len_s1==len_s2){
    for(i=0;i<len_s1;i++){
      if(s1[i]!=s2[i])
        diffr++;
      }
    }
    else if(len_s1 > len_s2){
      for(i=0;i<len_s2;i++){
        if(s1[i]!=s2[i])
          diffr++;
      }
     diffr=diffr+len_s1-len_s2;
    }
   else{
   for(i=0;i<len_s1;i++){
     if(s1[i]!=s2[i])
       diffr++;
    }
    diffr=diffr+len_s2-len_s1;
    }
  return len_s1;

}// end of function
