#include <stdio.h>

void rm_left_space(char *s){
  int index, i, j;
  index = 0;

  // find last index of whitespace character 
  while(s[index] == ' ' || s[index] == '\t' || s[index] == '\n'){
    index++;
  }
  if(index != 0){
  //shift all trailing characters to its left 
    i = 0;
    while(s[i + index] != '\0'){
      s[i] = s[i + index];
      i++;
    }
  s[i] = '\0'; // string is NULL terminated
  }
}// end of function
