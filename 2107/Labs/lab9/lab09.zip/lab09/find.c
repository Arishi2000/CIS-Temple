#include <stdio.h>

int find(char *h, char *n){
  for(int i = 0; i < h[i] != '\0'; i++){
          int matched = 1;
          int previous_i = i;
          for(int j = 0; n[j] != '\0'; j++){
            if(h[previous_i] != '\0' && h[previous_i] == n[j]){
              previous_i++;
              continue;
            }else{
               matched = 0;
               break;
            }
          }
        if(matched == 1){
          return i;
        }
  }
  return -1;

}// end function
