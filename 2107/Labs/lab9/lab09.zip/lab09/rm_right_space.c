#include <stdio.h>

int rm_right_space(char *s){
  int index, i;

  // setting default index first
  index = -1;

  // find last index of non-white space character 
  i = 0;

  while(s[i] != '\0'){
    if(s[i] != ' ' && s[i] != '\t' && s[i] != '\n'){
      index = i;
    }
    i++;
  }

  // mark next character to last non-white space character as NULL
  s[index + 1] = '\0';
} //end main
