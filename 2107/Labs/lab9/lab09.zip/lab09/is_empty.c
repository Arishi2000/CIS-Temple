#include <stdio.h>

int is_empty(char *s){
  if(s == NULL){
    return 1;
  }
  //look for ANY kinds of white space and we consider it as empty 
  for(int i = 0; s[i] != '\0'; i++){
    if(s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\v' || s[i] == '\f' || s[i] == '\r' ){
      continue;
    }else{
    return 0;
    }
  }
  return 1;
}//end fuction
