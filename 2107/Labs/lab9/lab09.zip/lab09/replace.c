#include<stdio.h>

char *replace(char *s, char *pat, char *rep){

}//end of fuction
