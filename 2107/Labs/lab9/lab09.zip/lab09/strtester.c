#include "strtester.h"
#include <stdio.h>
#include <ctype.h>

int main(void){
 
  puts("1. Test for all_letters");
  char *s = "hello";
  int all_letters_ = all_letters(s);
  printf("%s%s", "Input: ", s);
  printf("\n%d\n\n", all_letters(s)); 
 
  puts("2. Test for num_in_range");
  char *s2 = "Yellow";
  int num_in_range_ = num_in_range(s2, 'f', 'm');
  printf("%s%s%s%c%s%s%c%s", "Input: ", s2, " '", 'f', "' ", "'", 'm', "'\n" ); 
  printf("%d\n\n", num_in_range_);

  puts("3. Test for diff");
  char *s3 = "Book";
  char *s4 = "Back";
  int diff_ = diff(s3, s4);
  printf("%s%s\t%s\n","Input: ", s3, s4);
  printf("%d\n\n", diff_);

  puts("4. Test for shorten");
  char s5[] = "Hello World";
  printf("%s%s\t%d\n", "Input: ", s5, 5);
  shorten(s5, 5);
  printf("%s\n\n", s5);
 
  puts("5. Test for len_diff");
  char *s6 = "Philadelphia";
  char *s7 = "Hello";
  printf("%s%s\t%s", "Input: ", s6, s7);
  int len_diff_ = len_diff(s6, s7);
  printf("\n%d\n\n", len_diff_);   

  puts("6. Test for rm_left_space");
  char s9[] = "  Hello";
  printf("%s%s%s\n", "Input:  \"", s9, "\"");
  rm_left_space(s9);
  printf("%s\n\n", s9);

  puts("7. Test for rm_right_space");
  char s10[] = "Hello  ";
  printf("%s%s%s\n", "Input: \"", s10, "\"");
  rm_right_space(s10);
  printf("%s\n\n", s10);

  puts("8. Test for rm_space");
  char s11[] = "  Hello  ";
  printf("%s%s%s\n", "Input: \"", s11, "\"");
  rm_space(s11);
  printf("%s\n\n", s11);

  puts("9. Test for find");
  char *s12 = "l";
  char *s13 = "q";
  printf("%s%s\t%s", "Input: ", s7, s12);
  int find_ = find(s7, s12);
  printf("\n%d\n\n", find_); 

  puts("10. Test for ptr_to");
  printf("%s%s\t%s\n", "Input: ", s7, s12);
  char *ptr = ptr_to(s7, s12);
  printf("%s%s\n\n", "pointer to ",ptr);   

  puts("11. Test for is_empty");
  char *s14 = " ";
  printf("%s%s%s\n", "Input: \"", s14, "\"");
  printf("%d\n\n", is_empty(s14));

  puts("12. Test for str_zip");
  char s15[] = "Temple";
  char s24[] = "Hello";
  printf("%s%s%s%s%s\n", "Input: \"", s15, "\" \"", s24, "\""); 
  printf("%s\n\n", str_zip(s15, s24));

  puts("13. Test for capitalize");
  char s16[10] = "hello";
  printf("%s%s\n", "Input: ", s16);
  capitalize(s16);
  printf("%s\n\n", s16);  

  puts("14. Test for strcmp_ign_case");
  char *s25 = "hello";
  char *s26 = "goodbye";
  printf("%s%s\t%s\n","Input: ", s26, s26);
  int strcmp_ = strcmp_ign_case(s25, s26);
  printf("%d\n\n", strcmp_);

  puts("15. Test for take_last");
  char s17[] = "hello";
  printf("%s%s\t%d\n", "Input: ", s17, 3);
  take_last(s17, 3);
  printf("%s\n\n", s17);   

  puts("16. Test for dedup");
  printf("%s%s\n", "Input: ", "hello");
  char *s20 = dedup("hello");
  printf("%s\n\n", s20);

  puts("17. Test for pad");
  char s27[] = "hello";
  printf("%s%s\t%d\n", "Input: ", s27, 6);
  pad(s27,5);
  printf("%s\n\n", s27);

  puts("18. Test for ends_with_ignore_case");
  char s18[] = "Coding";
  char s19[] = "ing";
  printf("%s%s\t%s\n","Input: ", s18, s19);
  printf("%d\n\n", ends_with_ignore_case(s18, s19));

  puts("19. Test for repeat");
  char s21[100] = "hello";
  printf("%s%s\t%d\t%s\n", "Input: ", s21, 3, "-");
  char *s22 = repeat(s21, 3, '-');
  printf("%s\n\n", s22);  

  puts("20. Test for replace");
  char *replace1 = "Steph is the X";
  char *replace2 = "X";
  char *replace3 = "best";
  char *replace_;
  printf("%s%s\t%s\t%s\n", "Input: ", replace1, replace2, replace3);
  replace_ = replace(replace1, replace2, replace3);
  printf("%s\n\n", replace_);

  puts("21. Test for str_connect");
  char *strs[] = { "Hello", "world", "Hello", "world" };
  char *ans;
  ans = str_connect(strs, 4, '+');
  printf("%s\n\n", ans);  

  puts("22. Test for rm_empties");
  char *array[] = {"Hello", "World", "", "", "Steph"};  
  printf("%s", "Input: ");
  int i = 0;
  while(array[i] != NULL){
    printf("%s ", array[i]);
    i++;
  }
  rm_empties(array);

  i = 0;
  printf("\n");
  while(array[i] != NULL){
    printf("%s ", array[i]);
    i++;
  }
  printf("\n\n");

  puts("23. Test for str_chop_all");
  char *s23 = "Hello/world/hello/world";
  printf("%s%s%s\n", "Input: \"", s23, "\"");
  char **result = str_chop_all(s23, "/");
  printf("%s\n\n", result);

} //end main
