#include<stdio.h>
#include<stdlib.h>

char *pad(char *s, int d){
  int size = 0;
  while(s[size] != '\0'){
    size++;
  }
  char *retvalue = s;
  if(size % d == 0){
    return s;
  }else{
    int num = (size %d) - d;
    for(size_t i = size; i < num + size; i++){
      retvalue[i] = ' ';
    }
  }
}// end of function

