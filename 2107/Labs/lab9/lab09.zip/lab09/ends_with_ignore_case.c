#include<stdio.h>

int ends_with_ignore_case(char *s, char *stuff){
  char *temp = stuff;
  int count = 0;
  while(*(count + temp)!= '\0')
    count++;
  int mainStringCount = 0;
  while(*(mainStringCount + s) != '\0')
    mainStringCount++;
  for(int i = count - 1; i >= 0; i--)
    if(*(s + --mainStringCount) != *(stuff + i))
    return 0;
    return 1;
} // end of function
